class Shop:
    offers = [
        {
         "OfferID": 16,
         "DataReference": [16,0],
         "ShopType": 0,
         "ShopDisplay": 0,
         "Cost": 0,
         "Timer": 3600,
         "Multiplier": 500,
         "OfferText": "ПОДАРОК",
         "Claimed": False,
         "OfferBG": 'offer_lunar'
      }

    ]


