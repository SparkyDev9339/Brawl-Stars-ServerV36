from Protocol.Messages.Client.ClientHelloMessage import ClientHelloMessage
#Login
from Protocol.Messages.Client.LoginMessage import LoginMessage
#Profile
from Protocol.Messages.Client.GetPlayerProfileMessage import GetPlayerProfileMessage
#LeaderBoard
from Protocol.Messages.Client.GetLeaderboardMessage import GetLeaderboardMessage
#BattleEnd
from Protocol.Messages.Client.AskForBattleEndMessage import AskForBattleEndMessage
#Aliance
from Protocol.Messages.Server.Aliance.AllianceListMessage import AllianceListMessage
from Protocol.Messages.Server.Aliance.ChangeAllianceSettingsMessage import ChangeAllianceSettingsMessage
#GameRoom
from Protocol.Messages.Server.Team.TeamCreateMessage import TeamCreateMessage
from Protocol.Messages.Server.Team.TeamMessage import TeamMessage


packets = {

    10100: ClientHelloMessage,
    10101: LoginMessage,
    14113: GetPlayerProfileMessage,
    14403: GetLeaderboardMessage,
    14110: AskForBattleEndMessage,
    24310: AllianceListMessage,
    24124: TeamMessage,
}
