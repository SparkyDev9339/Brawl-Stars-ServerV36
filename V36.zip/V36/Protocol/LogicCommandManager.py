from Protocol.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand

commands = {
	519: LogicPurchaseOfferCommand,
}