from ByteStream.Reader import Reader
from Protocol.Messages.Server.LoginOkMessage import LoginOkMessage
from Protocol.Messages.Server.OwnHomeDataMessage import OwnHomeDataMessage
#Aliance
from Protocol.Messages.Server.Aliance.AllianceDataMessage import AllianceDataMessage
from Protocol.Messages.Server.Aliance.MyAllianceMessage import MyAllianceMessage
from Protocol.Messages.Server.Aliance.AllianceStreamMessage import AllianceStreamMessage
#Lobby
from Lobby.MaintenceMessage import MaintenceMessage
from Lobby.WarMessage import WarMessage
#Friend
from Protocol.Messages.Server.Friends.FriendMessage import FriendMessage

class LoginMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, db):
        LoginOkMessage(self.client, self.player).send()
        OwnHomeDataMessage(self.client, self.player).send()
        #Aliance
        AllianceDataMessage(self.client, self.player, db).send()
        MyAllianceMessage(self.client, self.player, db).send()
        AllianceStreamMessage(self.client, self.player, db).send()
        #Lobby
        #MaintenceMessage(self.client, self.player).send()
        FriendMessage(self.client, self.player).send()
        WarMessage(self.client, self.player).send()